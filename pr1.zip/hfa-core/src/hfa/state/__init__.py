
from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

VALID_TRANSITIONS = {
    "admitted": {"queued", "scheduled", "failed", "cancelled"},
    "queued": {"scheduled", "failed", "cancelled"},
    "scheduled": {"running", "failed", "cancelled"},
    "running": {"completed", "failed", "rescheduled", "cancelled"},
    "rescheduled": {"admitted", "failed", "cancelled"},
    "completed": set(),
    "failed": set(),
    "cancelled": set(),
}
TERMINAL_STATES = {"completed", "failed", "cancelled"}


@dataclass(frozen=True)
class TransitionResult:
    ok: bool
    reason: str
    from_state: Optional[str]
    to_state: str
    run_id: str

    def __bool__(self) -> bool:
        return self.ok


def _app_env() -> str:
    return (os.getenv("APP_ENV") or os.getenv("ENVIRONMENT") or "development").strip().lower()


def _strict_mode() -> bool:
    return _app_env() in {"production", "staging"}


def validate_transition(current: Optional[str], target: str) -> TransitionResult:
    if current is None:
        return TransitionResult(False, "initial_write_blocked", current, target, "")
    if current in TERMINAL_STATES:
        return TransitionResult(False, "terminal_blocked", current, target, "")
    allowed = VALID_TRANSITIONS.get(current)
    if allowed is None:
        return TransitionResult(False, "unknown_state_fail_closed", current, target, "")
    if target not in allowed:
        return TransitionResult(False, "illegal_transition", current, target, "")
    return TransitionResult(True, "committed", current, target, "")


async def transition_state(
    redis,
    *,
    run_id: str,
    expected_state: Optional[str],
    target_state: str,
    ttl_seconds: int = 60,
    lua_loader=None,
):
    verdict = validate_transition(expected_state, target_state)
    if not verdict.ok:
        return TransitionResult(False, verdict.reason, expected_state, target_state, run_id)

    if lua_loader is None and _strict_mode():
        raise RuntimeError("Lua CAS required in staging/production")

    if lua_loader is not None:
        await redis.set(run_id, target_state, ex=ttl_seconds)
        return TransitionResult(True, "committed", expected_state, target_state, run_id)

    current = await redis.get(run_id)
    if isinstance(current, bytes):
        current = current.decode("utf-8")
    if current != expected_state:
        return TransitionResult(False, "cas_miss", current, target_state, run_id)

    await redis.set(run_id, target_state, ex=ttl_seconds)
    return TransitionResult(True, "python_fallback_committed", expected_state, target_state, run_id)
