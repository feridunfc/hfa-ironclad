
from __future__ import annotations


class Scheduler:
    """Single-authority worker picker facade.

    Responsibilities:
    - consume admitted events
    - enqueue into tenant queues
    - build capacity snapshots
    - invoke scoring
    - enforce pacing
    - commit scheduling through Lua/state transition
    """

    def _pick_best_worker(self, candidates):
        usable = []
        for candidate in candidates:
            if not getattr(candidate, "schedulable", True):
                continue
            if not getattr(candidate, "worker_id", None):
                continue
            if getattr(candidate, "decision_score", None) is None:
                continue
            usable.append(candidate)
        if not usable:
            return None
        usable.sort(key=lambda c: c.decision_score.as_sort_key())
        return usable[0]

    @staticmethod
    def pick_best_worker(workers: list[dict]) -> dict | None:
        valid = [
            w for w in workers
            if w.get("worker_id") and w.get("score") is not None and not w.get("unschedulable", False)
        ]
        if not valid:
            return None
        return sorted(valid, key=lambda w: (w["score"], w["worker_id"]))[0]
