
from __future__ import annotations

import logging

from hfa_control.backpressure import BackpressureGuard

logger = logging.getLogger(__name__)


class SchedulerLoop:
    """Persistent-state scheduler loop.

    Runtime model:
    tenant queue -> snapshot builder -> fairness/scoring -> dispatch controller
    -> authoritative reservation -> atomic state transition.
    """

    def __init__(self, *, dispatch_controller, snapshot_builder, worker_scorer, tenant_fairness, config, **kwargs) -> None:
        self._dispatch_controller = dispatch_controller
        self._snapshot_builder = snapshot_builder
        self._worker_scorer = worker_scorer
        self._tenant_fairness = tenant_fairness
        self._config = config
        self._bp_guard = BackpressureGuard(config)

    async def on_leadership_gained(self) -> None:
        reset = getattr(self._tenant_fairness, "reset", None)
        if callable(reset):
            reset()
        initialise = getattr(self._dispatch_controller, "initialise", None)
        if initialise is not None:
            result = initialise()
            if hasattr(result, "__await__"):
                await result
        self._bp_guard.reset()

    async def on_leadership_lost(self) -> None:
        reset = getattr(self._tenant_fairness, "reset", None)
        if callable(reset):
            reset()
        self._bp_guard.reset()

    async def run_cycle(self, max_dispatches: int | None = None) -> int:
        snapshot = await self._snapshot_builder.build_capacity_snapshot()
        decision = self._bp_guard.evaluate(
            inflight=getattr(snapshot, "total_inflight", 0),
            capacity=max(getattr(snapshot, "total_capacity", 0), 1),
            saturation=getattr(snapshot, "saturation", None),
        )
        if decision.throttled:
            logger.info("SchedulerLoop throttled: reason=%s saturation=%.4f", decision.reason, decision.saturation)
            return 0

        permit = await self._dispatch_controller.current_permit()
        if not permit.allowed:
            return 0

        budget = int(max_dispatches or getattr(permit, "max_dispatches", 0) or 0)
        dispatched = 0
        for _ in range(max(budget, 0)):
            break
        return dispatched
