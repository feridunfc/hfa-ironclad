
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class BackpressureDecision:
    throttled: bool
    reason: str | None
    saturation: float

    @property
    def in_soft_throttle(self) -> bool:
        return self.throttled and self.reason in {"soft_high", "soft_hysteresis"}

    @property
    def hard_cap_reached(self) -> bool:
        return self.reason == "hard_limit"


class BackpressureGuard:
    def __init__(self, config) -> None:
        self._config = config
        self._in_soft_throttle = False

    def reset(self) -> None:
        self._in_soft_throttle = False

    @property
    def is_soft_throttled(self) -> bool:
        return self._in_soft_throttle

    def evaluate(self, *, queued: int | None = None, inflight: int | None = None, capacity: int = 0, saturation: float | None = None) -> BackpressureDecision:
        value = inflight if inflight is not None else queued if queued is not None else 0

        if capacity <= 0:
            self._in_soft_throttle = True
            return BackpressureDecision(True, "no_capacity", 1.0)

        if saturation is None:
            saturation = value / float(max(capacity, 1))

        soft_high = float(getattr(self._config, "backpressure_soft_high", 0.90))
        ratio = float(getattr(self._config, "backpressure_hysteresis_ratio", 0.80))
        soft_low = float(getattr(self._config, "backpressure_soft_low", soft_high * ratio))
        hard = float(getattr(self._config, "backpressure_hard", 1.00))
        hard_cap = int(getattr(self._config, "backpressure_hard_cap", 0))
        if hard_cap > 0 and value >= hard_cap:
            self._in_soft_throttle = True
            return BackpressureDecision(True, "hard_limit", saturation)

        if saturation >= hard:
            self._in_soft_throttle = True
            return BackpressureDecision(True, "hard_limit", saturation)

        if self._in_soft_throttle:
            if saturation < soft_low:
                self._in_soft_throttle = False
            else:
                return BackpressureDecision(True, "soft_hysteresis", saturation)

        if saturation >= soft_high:
            self._in_soft_throttle = True
            return BackpressureDecision(True, "soft_high", saturation)

        return BackpressureDecision(False, None, saturation)
