
from __future__ import annotations

import inspect
import json
from typing import Any

from hfa.runtime.payload_store import PayloadStore


async def _maybe_await(result):
    if inspect.isawaitable(result):
        return await result
    return result


class InputResolver:
    def __init__(self, redis_client, payload_store: PayloadStore | None = None) -> None:
        self._redis = redis_client
        self._payload_store = payload_store

    async def resolve_input(self, task_id: str) -> Any:
        raw = await _maybe_await(self._redis.get(f"hfa:task:{task_id}:output"))
        if raw is None:
            raise KeyError(f"Missing output for task_id={task_id}")
        if isinstance(raw, bytes):
            raw = raw.decode("utf-8")
        record = json.loads(raw)

        mode = record["payload_mode"]
        if mode == "inline":
            return record["payload_inline"]
        if mode == "ref":
            if self._payload_store is None:
                raise RuntimeError("Payload ref found but no payload_store configured")
            data = await self._payload_store.get(
                record["payload_ref"],
                expected_checksum=record.get("checksum"),
            )
            if record.get("payload_type") == "text":
                return data.decode("utf-8")
            return data
        raise ValueError(f"Unknown payload_mode={mode}")
