
# 8A hardening apply notes

## Files
- hfa-core/src/hfa/runtime/payload_config.py
- hfa-core/src/hfa/runtime/payload_metrics.py
- hfa-core/src/hfa/runtime/payload_store.py
- hfa-core/src/hfa/runtime/state_store.py
- hfa-worker/src/hfa_worker/input_resolver.py
- tests/core/test_payload_store_hardening_core.py

## Verify
```powershell
.\.venv\Scripts\python -m pytest tests/core/test_payload_store_hardening_core.py -vv
```
