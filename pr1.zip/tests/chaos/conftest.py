import asyncio
import inspect
import pytest
import pytest_asyncio


class ChaosInjector:
    """Dağıtık sistem hata simülasyon aracı (Fault Injection)."""

    @staticmethod
    def simulate_redis_timeout():
        async def _mock_timeout(*args, **kwargs):
            await asyncio.sleep(0.05)
            raise ConnectionError("CHAOS: Redis connection timeout simulated")

        return _mock_timeout

    @staticmethod
    def simulate_connection_reset():
        async def _mock_reset(*args, **kwargs):
            await asyncio.sleep(0.01)
            raise ConnectionError("CHAOS: connection reset by peer")

        return _mock_reset


@pytest.fixture
def chaos_injector() -> ChaosInjector:
    return ChaosInjector()


# KRİTİK DÜZELTME: Asenkron jeneratörler STRICT modda kesinlikle pytest_asyncio ile sarmalanmalıdır!
@pytest_asyncio.fixture
async def redis_client():
    """Testler için izole edilmiş ve her test sonrası temizlenen Redis istemcisi."""
    client = None
    try:
        # Önce fakeredis dene (Hızlı lokal testler için)
        import fakeredis.aioredis as fakeredis
        client = fakeredis.FakeRedis(decode_responses=True)
    except ImportError:
        # Bulamazsa gerçek Redis'e fallback yap (Docker/Gerçek ortam için)
        import redis.asyncio as redis
        client = redis.Redis(host="localhost", port=6379, decode_responses=True)

    # Test başlamadan önce veritabanını temizle
    await client.flushdb()

    try:
        # İstemciyi teste gönder (Yield the connection)
        yield client
    finally:
        # Test bittikten sonra veritabanını temizle (Garbage Collection)
        try:
            await client.flushdb()
        except Exception:
            pass

        # İstemci türüne (fakeredis/real) göre güvenli kapatma rutini
        close_fn = getattr(client, "aclose", None) or getattr(client, "close", None)
        if close_fn is not None:
            result = close_fn()
            if inspect.isawaitable(result):
                await result